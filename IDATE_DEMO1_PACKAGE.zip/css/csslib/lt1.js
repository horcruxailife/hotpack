$(document).ready(function () {
    $(window).scroll(function () {
        var scroHei = $(window).scrollTop();
        if (scroHei > 100) {
            $('.gotop').css('opacity', '0.7');
            //  $('.navbar').css('background-color', opacitynavBackColor);
        } else {
            $('.gotop').css('opacity', '0');
        }
    })

    if ($('#home').hasClass('banner-full')) {
        $('.banner-full').html('')
    }

    $('.navbar-nav   li a').click(function () {
        var target = $(this).attr('href');
        var position = $(target).offset().top - 85;
        var duration = 1000;
        $("html, body").stop().animate({
            scrollTop: position
        }, duration
        );
        $('.navbar-collapse').removeClass('in');
        $('#nav-icon').removeClass('open');
    });



    $(".newsBt").each(function () {
        $(this).click(function () {
            $(this).parent().next().stop().slideToggle();
        });
    });
    $('.proArea').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 500,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }]
    });
    $('.gotop').click(function () {
        $('html,body').animate({

            scrollTop: 0

        }, 'slow'); /* 返回到最上 */

        return false;

    });
});